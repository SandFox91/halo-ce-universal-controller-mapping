#!/usr/bin/env python3
"""Generate SDL2 controller mappings from connected EmulationStation joysticks.

Default face buttons are identity (A->A etc.), as tested with the dedicated
Pan4Elec G350 V2. Set HALO_FACE_LAYOUT=swap for Nintendo-labelled configs
requiring SDL/Xbox-style face-button swapping. This script does not implement
MENU+START: that shortcut belongs to the launcher/firmware.
"""
import os
import re
import sys
import xml.etree.ElementTree as ET

CONFIGS = (
    '/storage/.emulationstation/es_input.cfg',
    '/home/ark/.emulationstation/es_input.cfg',
    '/userdata/system/configs/emulationstation/es_input.cfg',
    '/usr/share/emulationstation/es_input.cfg',
    '/etc/emulationstation/es_input.cfg',
    '/storage/.config/emulationstation/es_input.cfg',
)
BASE = {
    'a':'a', 'b':'b', 'x':'x', 'y':'y',
    'leftthumb':'leftstick', 'rightthumb':'rightstick',
    'l3':'leftstick', 'r3':'rightstick',
    'leftshoulder':'leftshoulder', 'rightshoulder':'rightshoulder',
    'pageup':'leftshoulder', 'pagedown':'rightshoulder',
    'lefttrigger':'lefttrigger', 'righttrigger':'righttrigger',
    'l2':'lefttrigger', 'r2':'righttrigger',
    'leftanalogleft':'leftx', 'leftanalogup':'lefty',
    'rightanalogleft':'rightx', 'rightanalogup':'righty',
    'joystick1left':'leftx', 'joystick1up':'lefty',
    'joystick2left':'rightx', 'joystick2up':'righty',
    'select':'back', 'start':'start', 'hotkey':'guide',
    'hotkeyenable':'guide',
    'up':'dpup', 'down':'dpdown', 'left':'dpleft', 'right':'dpright',
}
STICKS = {'leftx','lefty','rightx','righty'}
TRIGGERS = {'lefttrigger','righttrigger'}
GUID_RE = re.compile(r'^[0-9a-fA-F]{32}$')


def connected_names(devices_path='/proc/bus/input/devices'):
    try:
        with open(devices_path, encoding='utf-8', errors='replace') as stream:
            return set(re.findall(r'^N: Name="([^"]+)"', stream.read(), re.M))
    except OSError:
        return set()


def element(entry, sdl_name):
    kind = entry.get('type')
    try:
        ident = int(entry.get('id', ''))
        if not 0 <= ident <= 255:
            return None
        if kind == 'button':
            return 'b%d' % ident
        value = int(entry.get('value', ''))
        if kind == 'hat' and value in (1, 2, 4, 8):
            return 'h%d.%d' % (ident, value)
        if kind == 'axis' and value != 0:
            if sdl_name in STICKS:
                return 'a%d%s' % (ident, '' if value < 0 else '~')
            if sdl_name in TRIGGERS:
                return 'a%d%s' % (ident, '~' if value < 0 else '')
            return '%sa%d' % ('-' if value < 0 else '+', ident)
    except (ValueError, TypeError):
        pass
    return None


def generate(paths=CONFIGS, names=None, layout='identity'):
    if names is None:
        names = connected_names()
    if layout not in ('identity', 'swap'):
        raise ValueError('HALO_FACE_LAYOUT must be identity or swap')
    mapping = dict(BASE)
    if layout == 'swap':
        mapping.update({'a':'b', 'b':'a', 'x':'y', 'y':'x'})
    seen = set()
    output = []
    for path in paths:
        try:
            root = ET.parse(path).getroot()
        except (OSError, ET.ParseError) as exc:
            if os.environ.get('HALO_MAPPING_DEBUG') == '1':
                print('Skipping %s: %s' % (path, exc), file=sys.stderr)
            continue
        for cfg in root.iter('inputConfig'):
            name, guid = cfg.get('deviceName'), cfg.get('deviceGUID')
            if (cfg.get('type') != 'joystick' or name not in names
                    or not guid or not GUID_RE.fullmatch(guid)
                    or ',' in name or '\n' in name or guid.lower() in seen):
                continue
            assignments = {}
            for entry in cfg.iter('input'):
                target = mapping.get(entry.get('name'))
                if target and target not in assignments:
                    value = element(entry, target)
                    if value:
                        assignments[target] = value
            # Don't override SDL's built-in mappings with a nearly empty profile.
            if not all(k in assignments for k in ('a','b','x','y')):
                continue
            output.append(','.join([guid, name] + [
                '%s:%s' % (key, value) for key, value in assignments.items()
            ] + ['platform:Linux', '']))
            seen.add(guid.lower())
    return output


def main():
    try:
        print('\n'.join(generate(layout=os.environ.get('HALO_FACE_LAYOUT', 'identity'))))
    except ValueError as exc:
        print(str(exc), file=sys.stderr)
        return 2
    return 0


if __name__ == '__main__':
    sys.exit(main())
