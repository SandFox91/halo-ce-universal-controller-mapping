HALO CE — EXPERIMENTAL MULTI-FIRMWARE CONTROLLER MAPPING
Community documentation • 8 languages
Original port: https://github.com/kirklandsig/halo-ce-anbernic-rg35xx
No game data included. Keep a backup of the original script.

================================================================
English
================================================================
1. Experimental multi-firmware controller mapping for Halo CE.
2. Tested: dedicated Pan4Elec V2 fix on Batlexp G350. This experimental multi-firmware script has NOT been independently validated. ArkOS, DARKOS and Knulli are untested.
3. Intended mapping: physical A/B/X/Y = Halo A/B/X/Y. L3 crouch worked with the tested Pan4Elec V2. MENU + START exited the game on the tested device, but is not guaranteed by this script.
4. Back up roms/ports/halo/sdl_mapping.py. Copy the sdl_mapping.py from this ZIP to that location. Restart Halo and test every button. If anything fails, restore your backup.
5. The script searches several EmulationStation es_input.cfg locations. It does not detect every device or physical button layout. Do not describe it as universally compatible.

================================================================
Français
================================================================
1. Mapping de manette expérimental multi-firmware pour Halo CE.
2. Testé : correctif Pan4Elec V2 dédié sur Batlexp G350. Ce script multi-firmware expérimental n’a PAS été validé séparément. ArkOS, DARKOS et Knulli ne sont pas testés.
3. Mapping visé : boutons physiques A/B/X/Y = Halo A/B/X/Y. L3 pour s’accroupir fonctionnait avec la V2 Pan4Elec testée. MENU + START quittait le jeu sur cette console, sans garantie avec ce script.
4. Sauvegardez roms/ports/halo/sdl_mapping.py. Copiez à sa place le fichier sdl_mapping.py du ZIP. Relancez Halo et testez les touches. En cas de problème, restaurez la sauvegarde.
5. Le script cherche plusieurs emplacements es_input.cfg d’EmulationStation. Il ne détecte pas toutes les consoles ni toutes les dispositions physiques. Compatibilité universelle non garantie.

================================================================
Español
================================================================
1. Asignación experimental de mandos para varios firmwares de Halo CE.
2. Probado: parche específico Pan4Elec V2 en Batlexp G350. Este script experimental multifirmware NO se ha validado por separado. ArkOS, DARKOS y Knulli no están probados.
3. Asignación prevista: botones físicos A/B/X/Y = Halo A/B/X/Y. L3 para agacharse funcionó con Pan4Elec V2. MENU + START permitió salir en ese dispositivo, pero este script no lo garantiza.
4. Haz una copia de roms/ports/halo/sdl_mapping.py. Sustitúyelo por el archivo sdl_mapping.py del ZIP. Reinicia Halo y prueba los botones. Si hay problemas, restaura la copia.
5. El script busca es_input.cfg en varias rutas de EmulationStation. No detecta todas las consolas ni todas las distribuciones de botones. No se garantiza compatibilidad universal.

================================================================
Deutsch
================================================================
1. Experimentelles Controller-Mapping für Halo CE auf mehreren Firmwares.
2. Getestet: separater Pan4Elec-V2-Patch auf der Batlexp G350. Dieses experimentelle Multi-Firmware-Skript wurde NICHT separat überprüft. ArkOS, DARKOS und Knulli sind ungetestet.
3. Vorgesehen: physische Tasten A/B/X/Y = Halo A/B/X/Y. L3 zum Ducken funktionierte mit Pan4Elec V2. MENU + START beendete das Spiel auf diesem Gerät, wird durch dieses Skript aber nicht garantiert.
4. Sichere roms/ports/halo/sdl_mapping.py. Ersetze die Datei durch sdl_mapping.py aus dem ZIP. Starte Halo neu und teste alle Tasten. Bei Problemen die Sicherung wiederherstellen.
5. Das Skript sucht an mehreren EmulationStation-Pfaden nach es_input.cfg. Nicht alle Geräte und Tastenlayouts werden erkannt. Keine universelle Kompatibilitätsgarantie.

================================================================
Italiano
================================================================
1. Mappatura sperimentale del controller per Halo CE su più firmware.
2. Testato: patch Pan4Elec V2 dedicata su Batlexp G350. Questo script multi-firmware sperimentale NON è stato verificato separatamente. ArkOS, DARKOS e Knulli non sono testati.
3. Mappatura prevista: tasti fisici A/B/X/Y = Halo A/B/X/Y. L3 per accovacciarsi funzionava con Pan4Elec V2. MENU + START chiudeva il gioco su quel dispositivo, ma non è garantito da questo script.
4. Salva una copia di roms/ports/halo/sdl_mapping.py. Sostituiscilo con sdl_mapping.py dello ZIP. Riavvia Halo e prova i tasti. In caso di problemi ripristina la copia.
5. Lo script cerca es_input.cfg in diversi percorsi di EmulationStation. Non riconosce tutti i dispositivi o layout fisici. Compatibilità universale non garantita.

================================================================
Português
================================================================
1. Mapeamento experimental de controles para Halo CE em vários firmwares.
2. Testado: correção Pan4Elec V2 específica no Batlexp G350. Este script experimental multifirmware NÃO foi validado separadamente. ArkOS, DARKOS e Knulli não foram testados.
3. Mapeamento pretendido: botões físicos A/B/X/Y = Halo A/B/X/Y. L3 para agachar funcionou com Pan4Elec V2. MENU + START saiu do jogo nesse aparelho, mas este script não garante essa função.
4. Faça uma cópia de roms/ports/halo/sdl_mapping.py. Substitua pelo sdl_mapping.py do ZIP. Reinicie Halo e teste os botões. Se houver problemas, restaure a cópia.
5. O script procura es_input.cfg em vários caminhos do EmulationStation. Não detecta todos os aparelhos ou layouts físicos. Compatibilidade universal não garantida.

================================================================
日本語
================================================================
1. Halo CE 用の複数ファームウェア向け実験的コントローラーマッピングです。
2. 動作確認済み：Batlexp G350 の Pan4Elec 専用 V2 修正版。この実験的な複数ファームウェア対応スクリプト自体は未検証です。ArkOS、DARKOS、Knulli も未検証です。
3. 想定する割り当て：本体の A/B/X/Y ボタン = Halo の A/B/X/Y。L3 でしゃがむ操作は Pan4Elec V2 で確認済みです。MENU + START で終了できましたが、このスクリプトでは保証されません。
4. roms/ports/halo/sdl_mapping.py をバックアップしてください。ZIP 内の sdl_mapping.py で置き換え、Halo を再起動して各ボタンを確認します。問題があればバックアップを戻してください。
5. スクリプトは EmulationStation の複数の場所から es_input.cfg を探します。すべての機種やボタン配置を自動認識するわけではありません。汎用互換性は保証されません。

================================================================
Русский
================================================================
1. Экспериментальная настройка кнопок контроллера для Halo CE на разных прошивках.
2. Проверено: отдельное исправление Pan4Elec V2 на Batlexp G350. Этот экспериментальный скрипт для нескольких прошивок отдельно НЕ проверялся. ArkOS, DARKOS и Knulli также не тестировались.
3. Ожидаемое соответствие: физические кнопки A/B/X/Y = кнопки A/B/X/Y в Halo. Нажатие L3 для приседания работало с проверенной версией Pan4Elec V2. Сочетание MENU + START позволяло выйти из игры на этой консоли, но данный скрипт не гарантирует его работу.
4. Сохраните резервную копию roms/ports/halo/sdl_mapping.py. Замените этот файл версией sdl_mapping.py из ZIP-архива. Перезапустите Halo и проверьте все кнопки. Если возникнут проблемы, восстановите резервную копию.
5. Скрипт ищет файл es_input.cfg в нескольких каталогах EmulationStation. Он не распознаёт автоматически все устройства и варианты расположения кнопок. Универсальная совместимость не гарантируется.
