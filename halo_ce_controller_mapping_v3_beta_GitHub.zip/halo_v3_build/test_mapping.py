import importlib.util
import pathlib
import tempfile
import unittest

ROOT = pathlib.Path(__file__).parent
spec = importlib.util.spec_from_file_location('halo_mapping', ROOT / 'sdl_mapping.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
REAL = pathlib.Path(__file__).parent / 'fixtures' / 'g350_es_input.cfg'

class MappingTests(unittest.TestCase):
    def test_g350_identity(self):
        result = m.generate([str(REAL)], {'GO-Super Gamepad'})
        self.assertEqual(len(result), 1)
        self.assertIn('a:b1', result[0])
        self.assertIn('b:b0', result[0])
        self.assertIn('x:b2', result[0])
        self.assertIn('y:b3', result[0])
        self.assertIn('leftstick:b14', result[0])
        self.assertIn('rightstick:b15', result[0])
    def test_swap_option(self):
        result = m.generate([str(REAL)], {'GO-Super Gamepad'}, 'swap')[0]
        self.assertIn('a:b0', result)
        self.assertIn('b:b1', result)
        self.assertIn('x:b3', result)
        self.assertIn('y:b2', result)
    def test_unknown_device_not_mapped(self):
        self.assertEqual(m.generate([str(REAL)], {'not-a-controller'}), [])
    def test_no_duplicate_guid(self):
        self.assertEqual(len(m.generate([str(REAL), str(REAL)], {'GO-Super Gamepad'})), 1)
    def test_invalid_xml_and_missing_file(self):
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d) / 'bad.cfg'
            p.write_text('<bad', encoding='utf-8')
            self.assertEqual(m.generate([str(p), str(p)+'missing'], {'GO-Super Gamepad'}), [])
    def test_axes(self):
        from xml.etree.ElementTree import Element
        self.assertEqual(m.element(Element('input', {'type':'axis','id':'1','value':'1'}),'lefty'),'a1~')
        self.assertEqual(m.element(Element('input', {'type':'axis','id':'1','value':'-1'}),'lefty'),'a1')
        self.assertIsNone(m.element(Element('input', {'type':'axis','id':'evil','value':'1'}),'lefty'))
    def test_invalid_layout(self):
        with self.assertRaises(ValueError):
            m.generate([], set(), 'other')

if __name__ == '__main__':
    unittest.main()
