HALO CE — COMMUNITY CONTROLLER MAPPING V3 BETA
================================================
ENGLISH
Status: experimental, NOT verified on ArkOS, DARKOS, or Knulli.
V3 Beta has been tested in-game and confirmed working by the project maintainer
on BATLEXP G350 running Pan4Elec. Other devices/firmwares remain untested.

Installation: back up roms/ports/halo/sdl_mapping.py first, then copy
this ZIP's sdl_mapping.py over it. Do not copy test_mapping.py or fixtures.
Default mapping is A=A, B=B, X=X, Y=Y (SDL labels).
If your firmware uses Nintendo-style EmulationStation labels, this may
require a different layout. Advanced users can set HALO_FACE_LAYOUT=swap
in the launcher environment before it invokes sdl_mapping.py.
The script only emits SDL_GAMECONTROLLERCONFIG entries for connected
controllers matching a valid EmulationStation profile. It does not add
MENU+START exit handling; that depends on the game launcher/firmware.
If the mapping fails, restore your backup. Only replace the original file after making a backup.
To run offline tests: python3 -m unittest -v test_mapping.py
No Halo game assets included. Respect the upstream project's license.

FRANÇAIS
Statut : expérimental, NON testé sur ArkOS, DARKOS ni Knulli.
La V3 Beta a été testée en jeu et confirmée fonctionnelle par le mainteneur
sur BATLEXP G350 / Pan4Elec. Les autres appareils/CFW restent à tester.

Installation : sauvegardez roms/ports/halo/sdl_mapping.py, puis remplacez
ce fichier par celui de l'archive. Ne copiez ni les tests ni fixtures.
Par défaut : A=A, B=B, X=X, Y=Y (noms SDL). Certains firmwares
utilisent une disposition EmulationStation de type Nintendo : le réglage
avancé HALO_FACE_LAYOUT=swap permet d'inverser A/B et X/Y dans le launcher.
Le script détecte les profils de manettes connectées et génère le mapping
SDL, mais NE gère PAS directement MENU+START pour quitter.
En cas de problème, restaurez le fichier sauvegardé. Remplacez uniquement le fichier original après sauvegarde.
Tests hors console : python3 -m unittest -v test_mapping.py
Aucune donnée du jeu incluse. Respectez la licence du projet original.

See README_MULTILINGUAL.txt for V3 Beta status and installation in 8 languages.
