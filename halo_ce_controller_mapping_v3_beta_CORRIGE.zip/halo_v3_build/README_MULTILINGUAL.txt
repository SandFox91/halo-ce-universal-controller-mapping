HALO CE — EXPERIMENTAL MULTI-FIRMWARE CONTROLLER MAPPING
Community documentation • 8 languages
Original port: https://github.com/kirklandsig/halo-ce-anbernic-rg35xx
No game data included. Keep a backup of the original script.

================================================================
English
================================================================
1. Experimental multi-firmware controller mapping for Halo CE.
2. V3 Beta tested in-game and confirmed working on BATLEXP G350 / Pan4Elec by the maintainer. ArkOS, DARKOS, Knulli and other devices remain untested.
3. Intended mapping: physical A/B/X/Y = Halo A/B/X/Y. L3 crouch was confirmed on the tested G350 / Pan4Elec. MENU + START exited the game on the tested device, but is not guaranteed by this script.
4. Back up roms/ports/halo/sdl_mapping.py. Copy the sdl_mapping.py from this ZIP to that location. Restart Halo and test every button. If anything fails, restore your backup.
5. The script searches several EmulationStation es_input.cfg locations. It does not detect every device or physical button layout. Do not describe it as universally compatible.

================================================================
Français
================================================================
1. Mapping de manette expérimental multi-firmware pour Halo CE.
2. V3 Beta testée en jeu et confirmée fonctionnelle sur BATLEXP G350 / Pan4Elec par le mainteneur. ArkOS, DARKOS, Knulli et les autres appareils restent à tester.
3. Mapping visé : boutons physiques A/B/X/Y = Halo A/B/X/Y. L3 pour s’accroupir a été confirmé sur G350 / Pan4Elec. MENU + START quittait le jeu sur cette console, sans garantie avec ce script.
4. Sauvegardez roms/ports/halo/sdl_mapping.py. Copiez à sa place le fichier sdl_mapping.py du ZIP. Relancez Halo et testez les touches. En cas de problème, restaurez la sauvegarde.
5. Le script cherche plusieurs emplacements es_input.cfg d’EmulationStation. Il ne détecte pas toutes les consoles ni toutes les dispositions physiques. Compatibilité universelle non garantie.

================================================================
Español
================================================================
1. Asignación experimental de mandos para varios firmwares de Halo CE.
2. V3 Beta probada en el juego y confirmada en BATLEXP G350 / Pan4Elec por el responsable del proyecto. ArkOS, DARKOS, Knulli y otros dispositivos siguen sin probarse.
3. Asignación prevista: botones físicos A/B/X/Y = Halo A/B/X/Y. L3 para agacharse se confirmó en G350 / Pan4Elec. MENU + START permitió salir en ese dispositivo, pero este script no lo garantiza.
4. Haz una copia de roms/ports/halo/sdl_mapping.py. Sustitúyelo por el archivo sdl_mapping.py del ZIP. Reinicia Halo y prueba los botones. Si hay problemas, restaura la copia.
5. El script busca es_input.cfg en varias rutas de EmulationStation. No detecta todas las consolas ni todas las distribuciones de botones. No se garantiza compatibilidad universal.

================================================================
Deutsch
================================================================
1. Experimentelles Controller-Mapping für Halo CE auf mehreren Firmwares.
2. V3 Beta wurde im Spiel auf BATLEXP G350 / Pan4Elec vom Projektbetreuer erfolgreich getestet. ArkOS, DARKOS, Knulli und andere Geräte sind ungetestet.
3. Vorgesehen: physische Tasten A/B/X/Y = Halo A/B/X/Y. L3 zum Ducken wurde auf G350 / Pan4Elec bestätigt. MENU + START beendete das Spiel auf diesem Gerät, wird durch dieses Skript aber nicht garantiert.
4. Sichere roms/ports/halo/sdl_mapping.py. Ersetze die Datei durch sdl_mapping.py aus dem ZIP. Starte Halo neu und teste alle Tasten. Bei Problemen die Sicherung wiederherstellen.
5. Das Skript sucht an mehreren EmulationStation-Pfaden nach es_input.cfg. Nicht alle Geräte und Tastenlayouts werden erkannt. Keine universelle Kompatibilitätsgarantie.

================================================================
Italiano
================================================================
1. Mappatura sperimentale del controller per Halo CE su più firmware.
2. V3 Beta testata in gioco e confermata funzionante su BATLEXP G350 / Pan4Elec dal responsabile del progetto. ArkOS, DARKOS, Knulli e altri dispositivi non sono ancora testati.
3. Mappatura prevista: tasti fisici A/B/X/Y = Halo A/B/X/Y. L3 per accovacciarsi è stato confermato su G350 / Pan4Elec. MENU + START chiudeva il gioco su quel dispositivo, ma non è garantito da questo script.
4. Salva una copia di roms/ports/halo/sdl_mapping.py. Sostituiscilo con sdl_mapping.py dello ZIP. Riavvia Halo e prova i tasti. In caso di problemi ripristina la copia.
5. Lo script cerca es_input.cfg in diversi percorsi di EmulationStation. Non riconosce tutti i dispositivi o layout fisici. Compatibilità universale non garantita.

================================================================
Português
================================================================
1. Mapeamento experimental de controles para Halo CE em vários firmwares.
2. V3 Beta testada no jogo e confirmada no BATLEXP G350 / Pan4Elec pelo responsável do projeto. ArkOS, DARKOS, Knulli e outros dispositivos ainda não foram testados.
3. Mapeamento pretendido: botões físicos A/B/X/Y = Halo A/B/X/Y. L3 para agachar foi confirmado no G350 / Pan4Elec. MENU + START saiu do jogo nesse aparelho, mas este script não garante essa função.
4. Faça uma cópia de roms/ports/halo/sdl_mapping.py. Substitua pelo sdl_mapping.py do ZIP. Reinicie Halo e teste os botões. Se houver problemas, restaure a cópia.
5. O script procura es_input.cfg em vários caminhos do EmulationStation. Não detecta todos os aparelhos ou layouts físicos. Compatibilidade universal não garantida.

================================================================
日本語
================================================================
1. Halo CE 用の複数ファームウェア向け実験的コントローラーマッピングです。
2. V3 Beta は BATLEXP G350 / Pan4Elec の実機ゲーム内でプロジェクト管理者が動作確認済みです。ArkOS、DARKOS、Knulli、その他の機種は未検証です。
3. 想定する割り当て：本体の A/B/X/Y ボタン = Halo の A/B/X/Y。L3 でしゃがむ操作は G350 / Pan4Elec で確認済みです。MENU + START で終了できましたが、このスクリプトでは保証されません。
4. roms/ports/halo/sdl_mapping.py をバックアップしてください。ZIP 内の sdl_mapping.py で置き換え、Halo を再起動して各ボタンを確認します。問題があればバックアップを戻してください。
5. スクリプトは EmulationStation の複数の場所から es_input.cfg を探します。すべての機種やボタン配置を自動認識するわけではありません。汎用互換性は保証されません。

================================================================
Русский
================================================================
1. Экспериментальная настройка кнопок контроллера для Halo CE на разных прошивках.
2. V3 Beta проверена в игре и подтверждена автором проекта на BATLEXP G350 / Pan4Elec. ArkOS, DARKOS, Knulli и другие устройства пока не тестировались.
3. Ожидаемое соответствие: физические кнопки A/B/X/Y = кнопки A/B/X/Y в Halo. Приседание по L3 подтверждено на G350 / Pan4Elec. Сочетание MENU + START позволяло выйти из игры на этой консоли, но данный скрипт не гарантирует его работу.
4. Сохраните резервную копию roms/ports/halo/sdl_mapping.py. Замените этот файл версией sdl_mapping.py из ZIP-архива. Перезапустите Halo и проверьте все кнопки. Если возникнут проблемы, восстановите резервную копию.
5. Скрипт ищет файл es_input.cfg в нескольких каталогах EmulationStation. Он не распознаёт автоматически все устройства и варианты расположения кнопок. Универсальная совместимость не гарантируется.
